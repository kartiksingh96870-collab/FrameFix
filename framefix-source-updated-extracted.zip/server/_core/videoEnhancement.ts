import { createHash, createHmac, timingSafeEqual } from "node:crypto";
import type { Express, Request, Response } from "express";

const VANCE_API = "https://vanceai.com/api/v1";
const SUPPORTED_VIDEO_TYPES = new Map<string, string>([
  [".mp4", "video/mp4"],
  [".mov", "video/quicktime"],
]);

class ApiError extends Error {
  constructor(
    message: string,
    readonly statusCode: number,
    readonly retryAfterSeconds?: number,
  ) {
    super(message);
  }
}

type VanceEnvelope = {
  error?: { code?: string; message?: string } | string;
  [key: string]: unknown;
};

type VanceUpload = {
  upload_id?: string;
  put_url?: string;
  expires_at?: string;
  max_bytes?: number;
};

type VanceVideoResult = {
  width?: number;
  height?: number;
  duration?: number;
  size?: number;
  codec?: string;
};

type VanceJob = {
  job_id?: string;
  status?: string;
  phase?: string;
  progress?: number;
  credits_estimated?: number;
  credits_charged?: number;
  result?: VanceVideoResult | null;
  error?: { code?: string; message?: string } | string | null;
};

function getApiKey(): string {
  const key = process.env.VANCEAI_API_KEY?.trim();
  const placeholder = /^(?:dummy|placeholder|changeme|replace[-_]?me|your[_-]?api[_-]?key|sk_live_(?:dummy|placeholder|changeme))/i.test(key ?? "");
  if (!key || placeholder || !key.startsWith("sk_live_")) {
    throw new ApiError(
      "VanceAI is not configured with a working key. Replace any dummy placeholder with a valid VANCEAI_API_KEY project secret to enable video processing.",
      503,
    );
  }
  return key;
}

function providerMessage(code: string, status: number, maxBytes?: number): string {
  if (code === "invalid_api_key" || status === 401) {
    return "The VanceAI API key is missing or invalid. Update the VANCEAI_API_KEY project secret.";
  }
  if (code === "insufficient_credits" || status === 402) {
    return "This VanceAI account needs more processing credits before it can enhance the video.";
  }
  if (code === "file_too_large" || status === 413) {
    const limit = Number.isSafeInteger(maxBytes) && Number(maxBytes) > 0
      ? ` The current single-upload limit is ${formatBytes(Number(maxBytes))}.`
      : " The provider's single-upload limit is about 4.9 GB.";
    return `This video is larger than VanceAI's current upload limit.${limit}`;
  }
  if (code === "rate_limited" || code === "concurrency_limit_exceeded" || status === 429) {
    return "VanceAI is busy or has reached its request limit. Wait a little and try again.";
  }
  if (code === "upload_expired") {
    return "The secure upload link expired. Start the enhancement again to get a fresh link.";
  }
  if (code === "unsupported_format" || code === "invalid_media") {
    return "VanceAI could not read this video. Try an MP4 or MOV file.";
  }
  if (code === "resolution_limit_exceeded" || code === "unsupported_resolution") {
    return "VanceAI's video upscaler accepts input up to 3840 × 2160 and outputs no larger than 4K.";
  }
  if (status === 404) return "That VanceAI job could not be found. Start a new enhancement.";
  return "VanceAI could not complete this request. Check the video and try again.";
}

function getProviderError(payload: unknown, status: number, maxBytes?: number): ApiError {
  const envelope = payload && typeof payload === "object" ? payload as VanceEnvelope : {};
  const details = typeof envelope.error === "object" && envelope.error
    ? envelope.error
    : undefined;
  const code = typeof details?.code === "string"
    ? details.code
    : typeof envelope.error === "string"
      ? envelope.error
      : "";
  return new ApiError(providerMessage(code, status, maxBytes), status === 413 ? 413 : status, undefined);
}

async function requestVance<T>(
  endpoint: string,
  options: { method?: "GET" | "POST"; body?: Record<string, unknown>; headers?: Record<string, string> } = {},
): Promise<T> {
  const apiKey = getApiKey();
  let response: globalThis.Response;
  try {
    response = await fetch(`${VANCE_API}${endpoint}`, {
      method: options.method ?? "GET",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        Accept: "application/json",
        ...(options.body ? { "Content-Type": "application/json" } : {}),
        ...options.headers,
      },
      ...(options.body ? { body: JSON.stringify(options.body) } : {}),
      signal: AbortSignal.timeout(30_000),
    });
  } catch {
    throw new ApiError("Could not reach VanceAI. Check the connection and try again.", 502, 8);
  }

  const raw = await response.text().catch(() => "");
  let payload: unknown = {};
  try {
    payload = raw ? JSON.parse(raw) : {};
  } catch {
    payload = {};
  }
  if (!response.ok) {
    const envelope = payload && typeof payload === "object" ? payload as VanceEnvelope : {};
    const error = typeof envelope.error === "object" && envelope.error ? envelope.error : undefined;
    const maxBytes = Number(envelope.max_bytes ?? (error as { max_bytes?: unknown } | undefined)?.max_bytes);
    const retry = Number(response.headers.get("retry-after"));
    const mapped = getProviderError(payload, response.status, Number.isFinite(maxBytes) ? maxBytes : undefined);
    throw new ApiError(mapped.message, mapped.statusCode, Number.isFinite(retry) && retry > 0 ? retry : undefined);
  }
  return payload as T;
}

function formatBytes(bytes: number): string {
  const gibibytes = bytes / 1024 ** 3;
  return `${gibibytes.toFixed(1)} GB`;
}

function safeUploadDetails(body: unknown): { fileName: string; fileSize: number; contentType: string } {
  if (!body || typeof body !== "object") throw new ApiError("Choose an MP4 or MOV video.", 400);
  const data = body as Record<string, unknown>;
  const suppliedName = typeof data.fileName === "string" ? data.fileName : "";
  const extension = suppliedName.toLowerCase().match(/\.(mp4|mov)$/)?.[0];
  const contentType = extension ? SUPPORTED_VIDEO_TYPES.get(extension) : undefined;
  const fileSize = Number(data.fileSize);
  if (!contentType || !Number.isSafeInteger(fileSize) || fileSize <= 0) {
    throw new ApiError("Choose an MP4 or MOV video whose file size can be read.", 400);
  }
  return {
    // Keep the selected filename private; the provider only needs a safe extension.
    fileName: `framefix-source${extension}`,
    fileSize,
    contentType,
  };
}

function validUploadId(value: unknown): value is string {
  return typeof value === "string" && /^upl_[a-zA-Z0-9_-]{4,160}$/.test(value);
}

function validJobId(value: unknown): value is string {
  return typeof value === "string" && /^job_[a-zA-Z0-9_-]{4,160}$/.test(value);
}

function parseQuality(value: unknown): "2k" | "4k" {
  if (value === "2k" || value === "4k") return value;
  throw new ApiError("Choose either the 2K or 4K upscale preset.", 400);
}

function signedJobToken(jobId: string, apiKey: string): string {
  return createHmac("sha256", apiKey).update(`framefix:vance-job:${jobId}`).digest("hex");
}

function hasJobAccess(jobId: string, supplied: unknown): boolean {
  if (typeof supplied !== "string") return false;
  let expected: string;
  try {
    expected = signedJobToken(jobId, getApiKey());
  } catch {
    return false;
  }
  const actualBuffer = Buffer.from(supplied);
  const expectedBuffer = Buffer.from(expected);
  return actualBuffer.length === expectedBuffer.length && timingSafeEqual(actualBuffer, expectedBuffer);
}

function sendError(response: Response, error: unknown): void {
  if (error instanceof ApiError) {
    response.setHeader("Cache-Control", "no-store");
    if (error.retryAfterSeconds) response.setHeader("Retry-After", String(error.retryAfterSeconds));
    response.status(error.statusCode).json({ message: error.message, retryAfterSeconds: error.retryAfterSeconds });
    return;
  }
  console.error("[FrameFix] VanceAI request failed", {
    code: error instanceof Error ? error.name : "unknown",
  });
  response.setHeader("Cache-Control", "no-store");
  response.status(502).json({ message: "VanceAI could not complete this request. Check the connection and try again." });
}

function numericField(value: unknown, minimum: number, maximum: number): number | undefined {
  const number = Number(value);
  return Number.isFinite(number) && number >= minimum && number <= maximum ? number : undefined;
}

async function createUpload(request: Request, response: Response): Promise<void> {
  try {
    const { fileName, fileSize, contentType } = safeUploadDetails(request.body);
    const upload = await requestVance<VanceUpload>("/uploads", {
      method: "POST",
      body: { file_name: fileName, file_size: fileSize, content_type: contentType },
    });
    const uploadId = upload.upload_id;
    const putUrl = upload.put_url;
    const maxBytes = Number(upload.max_bytes);
    if (!validUploadId(uploadId) || typeof putUrl !== "string" || !Number.isSafeInteger(maxBytes) || maxBytes <= 0) {
      throw new ApiError("VanceAI returned an invalid secure upload session. Try again.", 502);
    }
    let parsedPutUrl: URL;
    try {
      parsedPutUrl = new URL(putUrl);
    } catch {
      throw new ApiError("VanceAI returned an invalid secure upload link. Try again.", 502);
    }
    if (parsedPutUrl.protocol !== "https:") {
      throw new ApiError("VanceAI returned an insecure upload link. Try again.", 502);
    }
    if (fileSize > maxBytes) {
      throw new ApiError(`This video is larger than the upload limit of ${formatBytes(maxBytes)}. Choose a smaller file.`, 413);
    }
    response.setHeader("Cache-Control", "no-store");
    response.status(201).json({
      uploadId,
      uploadUrl: putUrl,
      maxBytes,
      expiresAt: upload.expires_at,
      contentType,
      fileSize,
    });
  } catch (error) {
    sendError(response, error);
  }
}

async function createEnhancementJob(request: Request, response: Response): Promise<void> {
  try {
    const body = request.body && typeof request.body === "object"
      ? request.body as Record<string, unknown>
      : {};
    const uploadId = body.uploadId;
    if (!validUploadId(uploadId)) throw new ApiError("The secure upload session is missing or expired. Upload the clip again.", 400);
    const quality = parseQuality(body.quality);
    const scale = quality === "4k" ? 4 : 2;
    const config: Record<string, unknown> = { scale };

    const idempotencyKey = `framefix-${createHash("sha256").update(`${uploadId}:${scale}`).digest("hex")}`;
    const created = await requestVance<VanceJob>("/jobs", {
      method: "POST",
      headers: { "Idempotency-Key": idempotencyKey },
      body: { upload_id: uploadId, tool: "video_upscale", config },
    });
    if (!validJobId(created.job_id)) throw new ApiError("VanceAI did not return a valid processing job. Try again.", 502);
    const apiKey = getApiKey();
    response.setHeader("Cache-Control", "no-store");
    response.status(202).json({
      jobId: created.job_id,
      jobToken: signedJobToken(created.job_id, apiKey),
      status: created.status ?? "queued",
      quality,
      scale,
      creditsEstimated: numericField(created.credits_estimated, 0, 1_000_000),
    });
  } catch (error) {
    sendError(response, error);
  }
}

function stageFor(job: VanceJob): string {
  if (job.status === "queued") return "Queued with VanceAI — waiting for an upscaler";
  if (job.status === "succeeded") return "Ready to review";
  if (job.status === "failed") return "VanceAI could not finish this video";
  if (job.status === "canceled") return "Enhancement canceled";
  if (job.phase === "uploading") return "VanceAI is receiving the video";
  if (job.phase === "syncing") return "Preparing the source for AI processing";
  if (job.phase === "processing") return "AI is restoring detail and upscaling";
  return "VanceAI is processing your video";
}

function jobErrorMessage(error: VanceJob["error"]): string {
  const code = typeof error === "object" && error ? String(error.code ?? "") : String(error ?? "");
  return providerMessage(code, code === "insufficient_credits" ? 402 : 500);
}

async function getFreshResultUrl(jobId: string): Promise<string | undefined> {
  const apiKey = getApiKey();
  let response: globalThis.Response;
  try {
    response = await fetch(`${VANCE_API}/jobs/${encodeURIComponent(jobId)}/result`, {
      method: "GET",
      headers: { Authorization: `Bearer ${apiKey}`, Accept: "application/json" },
      redirect: "manual",
      signal: AbortSignal.timeout(30_000),
    });
  } catch {
    throw new ApiError("VanceAI finished the upscale, but its download link could not be reached. Try again.", 502, 8);
  }
  if (response.status === 202) return undefined;
  if (response.status >= 300 && response.status < 400) {
    const location = response.headers.get("location");
    if (!location) throw new ApiError("VanceAI did not provide a result download link. Try again.", 502);
    const url = new URL(location, VANCE_API);
    if (url.protocol !== "https:") throw new ApiError("VanceAI returned an insecure result link. Try again.", 502);
    return url.toString();
  }
  if (!response.ok) {
    const raw = await response.text().catch(() => "");
    let payload: unknown = {};
    try { payload = raw ? JSON.parse(raw) : {}; } catch { payload = {}; }
    throw getProviderError(payload, response.status);
  }
  const payload = await response.json().catch(() => ({})) as { result_url?: unknown; url?: unknown };
  const link = typeof payload.result_url === "string" ? payload.result_url : payload.url;
  if (typeof link === "string" && link.startsWith("https://")) return link;
  return undefined;
}

async function getEnhancementStatus(request: Request, response: Response): Promise<void> {
  const jobId = request.params.jobId;
  if (!validJobId(jobId) || !hasJobAccess(jobId, request.query.token)) {
    response.status(404).json({ message: "This VanceAI job could not be found." });
    return;
  }
  try {
    const job = await requestVance<VanceJob>(`/jobs/${encodeURIComponent(jobId)}`);
    const status = job.status ?? "processing";
    const progress = Math.max(0, Math.min(100, Math.round(Number(job.progress) || 0)));
    let resultAvailable = false;
    if (status === "succeeded") {
      const freshResultUrl = await getFreshResultUrl(jobId);
      if (!freshResultUrl) {
        response.setHeader("Cache-Control", "no-store");
        response.json({
          jobId,
          status: "processing",
          progress: 98,
          stage: "Preparing your enhanced video",
          nextPollMs: 8_000,
        });
        return;
      }
      resultAvailable = true;
    }
    response.setHeader("Cache-Control", "no-store");
    response.json({
      jobId,
      status,
      phase: job.phase,
      progress,
      stage: stageFor(job),
      message: status === "failed" ? jobErrorMessage(job.error) : undefined,
      resultAvailable,
      result: job.result ?? undefined,
      creditsEstimated: numericField(job.credits_estimated, 0, 1_000_000),
      creditsCharged: numericField(job.credits_charged, 0, 1_000_000),
      nextPollMs: 7_000,
    });
  } catch (error) {
    sendError(response, error);
  }
}

async function redirectEnhancementResult(request: Request, response: Response): Promise<void> {
  const jobId = request.params.jobId;
  if (!validJobId(jobId) || !hasJobAccess(jobId, request.query.token)) {
    response.status(404).json({ message: "This VanceAI job could not be found." });
    return;
  }
  try {
    const outputUrl = await getFreshResultUrl(jobId);
    response.setHeader("Cache-Control", "private, no-store");
    if (!outputUrl) {
      response.status(409).json({ message: "The enhanced video is still being prepared. Please try again shortly." });
      return;
    }
    response.redirect(302, outputUrl);
  } catch (error) {
    sendError(response, error);
  }
}

async function cancelEnhancement(request: Request, response: Response): Promise<void> {
  const jobId = request.params.jobId;
  if (!validJobId(jobId) || !hasJobAccess(jobId, request.query.token)) {
    response.status(404).json({ message: "This VanceAI job could not be found." });
    return;
  }
  try {
    const result = await requestVance<VanceJob>(`/jobs/${encodeURIComponent(jobId)}/cancel`, { method: "POST" });
    response.setHeader("Cache-Control", "no-store");
    response.json({ status: result.status ?? "canceled" });
  } catch (error) {
    if (error instanceof ApiError && error.statusCode === 409) {
      response.setHeader("Cache-Control", "no-store");
      response.json({ status: "not_cancelable" });
      return;
    }
    sendError(response, error);
  }
}

export function registerVideoEnhancementRoutes(app: Express): void {
  app.post("/api/video/uploads", (request, response) => { void createUpload(request, response); });
  app.post("/api/video/enhance", (request, response) => { void createEnhancementJob(request, response); });
  app.get("/api/video/enhance/:jobId", (request, response) => { void getEnhancementStatus(request, response); });
  app.get("/api/video/enhance/:jobId/download", (request, response) => { void redirectEnhancementResult(request, response); });
  app.post("/api/video/enhance/:jobId/cancel", (request, response) => { void cancelEnhancement(request, response); });
}
