import axios from "axios";
import { Platform } from "react-native";
import * as FileSystem from "expo-file-system/legacy";
import type { ImagePickerAsset } from "expo-image-picker";
import { getApiBaseUrl } from "@/constants/oauth";

export type OutputQuality = "2k" | "4k";
export type JobStatus = "queued" | "processing" | "succeeded" | "failed" | "canceled";

export type UploadSession = {
  uploadId: string;
  uploadUrl: string;
  maxBytes: number;
  expiresAt?: string;
  contentType: string;
  fileSize: number;
};

export type VideoOutput = {
  width?: number;
  height?: number;
  duration?: number;
  size?: number;
  codec?: string;
};

export type EnhancementJob = {
  jobId: string;
  jobToken: string;
  status: string;
  quality: OutputQuality;
  scale: 2 | 4;
  creditsEstimated?: number;
};

export type EnhancementStatus = {
  jobId: string;
  status: JobStatus;
  phase?: string;
  progress: number;
  stage: string;
  message?: string;
  resultAvailable?: boolean;
  result?: VideoOutput;
  creditsEstimated?: number;
  creditsCharged?: number;
  nextPollMs?: number;
};

export type CancelOutcome = { status: string };

export type UploadTaskHandle = { cancelAsync: () => Promise<void> };
export type CancelTransfer = () => void | Promise<void>;

export class EnhancementRequestError extends Error {
  constructor(message: string, readonly retryable: boolean) {
    super(message);
  }
}

function apiUrl(path: string): string {
  return `${getApiBaseUrl().replace(/\/+$/, "")}${path}`;
}

function toRequestError(error: unknown, fallback: string): EnhancementRequestError {
  if (axios.isAxiosError(error)) {
    const data = error.response?.data as { message?: unknown; retryAfterSeconds?: unknown } | undefined;
    const message = typeof data?.message === "string" && data.message.length > 0
      ? data.message
      : fallback;
    const status = error.response?.status;
    return new EnhancementRequestError(message, !status || status === 408 || status === 425 || status === 429 || status >= 500);
  }
  return new EnhancementRequestError(
    error instanceof Error && error.message ? error.message : fallback,
    true,
  );
}

function sourceFileName(asset: ImagePickerAsset): string {
  const name = asset.fileName || asset.file?.name || "";
  const extension = name.toLowerCase().match(/\.(mp4|mov)$/)?.[0];
  if (extension) return `framefix-source${extension}`;
  const mimeType = asset.mimeType?.toLowerCase();
  if (mimeType === "video/quicktime") return "framefix-source.mov";
  if (mimeType === "video/mp4") return "framefix-source.mp4";
  throw new Error("VanceAI accepts MP4 or MOV videos. Convert this clip and try again.");
}

function sourceMimeType(asset: ImagePickerAsset): string {
  return sourceFileName(asset).endsWith(".mov") ? "video/quicktime" : "video/mp4";
}

async function sourceSize(asset: ImagePickerAsset): Promise<number> {
  const directSize = asset.fileSize ?? asset.file?.size;
  if (typeof directSize === "number" && Number.isSafeInteger(directSize) && directSize > 0) return directSize;
  if (Platform.OS !== "web") {
    const info = await FileSystem.getInfoAsync(asset.uri);
    if (info.exists && !info.isDirectory && Number.isSafeInteger(info.size) && info.size > 0) return info.size;
  }
  throw new Error("FrameFix could not read this video's file size. Re-select the video and try again.");
}

export async function createUploadSession(asset: ImagePickerAsset): Promise<UploadSession> {
  try {
    const fileSize = await sourceSize(asset);
    const response = await axios.post<UploadSession>(apiUrl("/api/video/uploads"), {
      fileName: sourceFileName(asset),
      fileSize,
      mimeType: sourceMimeType(asset),
    }, {
      timeout: 35_000,
      headers: { Accept: "application/json" },
    });
    if (response.data.maxBytes && fileSize > response.data.maxBytes) {
      const limit = (response.data.maxBytes / 1024 ** 3).toFixed(1);
      throw new Error(`This video exceeds VanceAI's current ${limit} GB upload limit. Choose a smaller file.`);
    }
    return response.data;
  } catch (error) {
    if (error instanceof Error && !axios.isAxiosError(error)) throw error;
    throw toRequestError(error, "The secure VanceAI upload could not be prepared.");
  }
}

export async function uploadVideoDirect(
  asset: ImagePickerAsset,
  session: UploadSession,
  onProgress: (percent: number) => void,
  onCancelReady: (cancel: CancelTransfer | null) => void,
): Promise<void> {
  if (Platform.OS === "web") {
    const file = asset.file;
    if (!file) throw new Error("The browser could not access the selected video file. Select it again and retry.");
    await new Promise<void>((resolve, reject) => {
      const request = new XMLHttpRequest();
      let settled = false;
      const finish = (error?: Error) => {
        if (settled) return;
        settled = true;
        onCancelReady(null);
        if (error) reject(error);
        else resolve();
      };
      request.open("PUT", session.uploadUrl, true);
      request.withCredentials = false;
      request.timeout = 0;
      request.setRequestHeader("Content-Type", session.contentType);
      request.upload.onprogress = (event) => {
        if (event.lengthComputable && event.total > 0) {
          onProgress(Math.min(100, Math.round((event.loaded / event.total) * 100)));
        }
      };
      request.onload = () => {
        if (request.status >= 200 && request.status < 300) finish();
        else if (request.status === 401 || request.status === 403) {
          finish(new Error("The secure upload link expired or was rejected. Start the enhancement again."));
        } else if (request.status === 413) {
          finish(new Error(`This video exceeds VanceAI's ${((session.maxBytes / 1024 ** 3).toFixed(1))} GB upload limit.`));
        } else {
          finish(new Error("VanceAI could not accept this upload. Check your connection and try again."));
        }
      };
      request.onerror = () => finish(new Error("The secure upload connection failed. Check your network and retry."));
      request.ontimeout = () => finish(new Error("The secure upload timed out. Retry on a stable connection."));
      request.onabort = () => finish(new Error("Video upload canceled."));
      onCancelReady(() => request.abort());
      request.send(file);
    });
    return;
  }

  const task = FileSystem.createUploadTask(
    session.uploadUrl,
    asset.uri,
    {
      httpMethod: "PUT",
      uploadType: FileSystem.FileSystemUploadType.BINARY_CONTENT,
      headers: { "Content-Type": session.contentType },
      sessionType: FileSystem.FileSystemSessionType.BACKGROUND,
    },
    (event) => {
      if (event.totalBytesExpectedToSend > 0) {
        onProgress(Math.min(100, Math.round((event.totalBytesSent / event.totalBytesExpectedToSend) * 100)));
      }
    },
  );
  onCancelReady(() => { void task.cancelAsync(); });
  try {
    const result = await task.uploadAsync();
    if (!result || result.status < 200 || result.status >= 300) {
      if (result?.status === 401 || result?.status === 403) {
        throw new Error("The secure upload link expired or was rejected. Start the enhancement again.");
      }
      if (result?.status === 413) {
        throw new Error(`This video exceeds VanceAI's ${((session.maxBytes / 1024 ** 3).toFixed(1))} GB upload limit.`);
      }
      throw new Error("VanceAI could not accept this upload. Check your connection and try again.");
    }
  } catch (error) {
    if (error instanceof Error && /cancel/i.test(error.message)) throw new Error("Video upload canceled.");
    if (error instanceof Error && error.message.startsWith("VanceAI could not") || error instanceof Error && error.message.startsWith("The secure upload")) {
      throw error;
    }
    throw new Error("The secure upload connection failed. Retry on a stable connection.");
  } finally {
    onCancelReady(null);
  }
}

export async function createEnhancementJob(
  uploadId: string,
  quality: OutputQuality,
): Promise<EnhancementJob> {
  try {
    const response = await axios.post<EnhancementJob>(apiUrl("/api/video/enhance"), {
      uploadId,
      quality,
    }, {
      timeout: 35_000,
      headers: { Accept: "application/json" },
    });
    return response.data;
  } catch (error) {
    throw toRequestError(error, "VanceAI could not start the upscaling job.");
  }
}

export async function getEnhancementStatus(jobId: string, jobToken: string): Promise<EnhancementStatus> {
  try {
    const response = await axios.get<EnhancementStatus>(
      apiUrl(`/api/video/enhance/${encodeURIComponent(jobId)}?token=${encodeURIComponent(jobToken)}`),
      { timeout: 35_000, headers: { Accept: "application/json" } },
    );
    return response.data;
  } catch (error) {
    throw toRequestError(error, "Could not read the VanceAI job status.");
  }
}

export function getEnhancementDownloadUrl(jobId: string, jobToken: string): string {
  return apiUrl(`/api/video/enhance/${encodeURIComponent(jobId)}/download?token=${encodeURIComponent(jobToken)}`);
}

export async function cancelEnhancement(jobId: string, jobToken: string): Promise<CancelOutcome> {
  try {
    const response = await axios.post<CancelOutcome>(
      apiUrl(`/api/video/enhance/${encodeURIComponent(jobId)}/cancel?token=${encodeURIComponent(jobToken)}`),
      {},
      { timeout: 35_000, headers: { Accept: "application/json" } },
    );
    return response.data;
  } catch (error) {
    throw toRequestError(error, "The VanceAI job could not be canceled.");
  }
}
