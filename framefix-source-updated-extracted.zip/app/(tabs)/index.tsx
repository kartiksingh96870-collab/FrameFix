import { Ionicons } from "@expo/vector-icons";
import * as FileSystem from "expo-file-system/legacy";
import * as ImagePicker from "expo-image-picker";
import * as MediaLibrary from "expo-media-library/legacy";
import { StatusBar } from "expo-status-bar";
import { useCallback, useEffect, useRef, useState } from "react";
import {
  ActivityIndicator,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import type { ImagePickerAsset } from "expo-image-picker";

import { ScreenContainer } from "@/components/screen-container";
import { VideoPreview } from "@/components/video-preview";
import {
  cancelEnhancement,
  createEnhancementJob,
  createUploadSession,
  EnhancementRequestError,
  getEnhancementDownloadUrl,
  getEnhancementStatus,
  uploadVideoDirect,
  type CancelTransfer,
  type EnhancementStatus,
  type OutputQuality,
  type VideoOutput,
} from "@/lib/video-enhancement";

type Phase = "empty" | "ready" | "uploading" | "processing" | "complete" | "error";
type CompareSide = "before" | "after";

const palette = {
  background: "#080C13",
  panel: "#101722",
  panelRaised: "#151F2C",
  border: "#263243",
  text: "#F3F6F8",
  muted: "#9AA6B7",
  subtle: "#657287",
  accent: "#C4FA62",
  accentInk: "#141C0B",
  blue: "#A5B7FF",
  red: "#FF938B",
};

function formatDuration(milliseconds?: number | null): string {
  if (!milliseconds || milliseconds <= 0) return "—";
  const totalSeconds = Math.floor(milliseconds / 1000);
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  return `${minutes}:${seconds.toString().padStart(2, "0")}`;
}

function formatSize(bytes?: number | null): string {
  if (!bytes || bytes <= 0) return "Size unavailable";
  const units = ["B", "KB", "MB", "GB"];
  let size = bytes;
  let unit = 0;
  while (size >= 1024 && unit < units.length - 1) {
    size /= 1024;
    unit += 1;
  }
  return `${size.toFixed(unit < 2 ? 0 : 1)} ${units[unit]}`;
}

function Detail({ icon, label, value }: { icon: keyof typeof Ionicons.glyphMap; label: string; value: string }) {
  return (
    <View style={styles.detailCell}>
      <View style={styles.detailTop}>
        <Ionicons name={icon} size={14} color={palette.subtle} />
        <Text style={styles.detailLabel}>{label}</Text>
      </View>
      <Text numberOfLines={1} style={styles.detailValue}>{value}</Text>
    </View>
  );
}

function EnhancementFeature({ icon, title, detail }: { icon: keyof typeof Ionicons.glyphMap; title: string; detail: string }) {
  return (
    <View style={styles.featureRow}>
      <View style={styles.featureIcon}>
        <Ionicons name={icon} size={16} color={palette.accent} />
      </View>
      <View style={styles.featureCopy}>
        <Text style={styles.featureTitle}>{title}</Text>
        <Text style={styles.featureDetail}>{detail}</Text>
      </View>
      <Ionicons name="checkmark" size={17} color={palette.accent} />
    </View>
  );
}

function ProgressCard({
  progress,
  stage,
  providerPhase,
  creditsEstimated,
  onCancel,
  cancelling,
}: {
  progress: number;
  stage: string;
  providerPhase?: string | null;
  creditsEstimated?: number;
  onCancel: () => void;
  cancelling: boolean;
}) {
  const hasMeasuredProgress = progress > 0;
  const isTransfer = providerPhase === "uploading";
  const progressTitle = providerPhase === "queued"
    ? "Waiting for a VanceAI worker"
    : providerPhase === "syncing"
      ? "Preparing the source video"
      : isTransfer ? "Secure upload in progress" : "Restoring your video";
  return (
    <View style={styles.progressCard}>
      <View style={styles.progressHeader}>
        <View style={styles.progressOrb}>
          <ActivityIndicator size="small" color={palette.accent} />
        </View>
        <View style={styles.progressCopy}>
          <Text style={styles.progressTitle}>{progressTitle}</Text>
          <Text style={styles.progressStage}>{stage}</Text>
        </View>
        {hasMeasuredProgress ? <Text style={styles.progressNumber}>{progress}%</Text> : null}
      </View>
      <View style={styles.track}>
        <View style={[styles.trackFill, { width: `${Math.max(3, progress)}%` }]} />
      </View>
      <View style={styles.progressFooter}>
        <Text style={styles.progressFootnote}>
          {typeof creditsEstimated === "number" && creditsEstimated > 0
            ? `Estimated ${creditsEstimated} VanceAI credits · reserved during processing; failed or canceled jobs are refunded`
            : "VanceAI reports processing progress as your video is restored."}
        </Text>
        <Pressable onPress={onCancel} disabled={cancelling} accessibilityRole="button" style={styles.cancelButton}>
          {cancelling ? <ActivityIndicator size="small" color={palette.muted} /> : <Text style={styles.cancelButtonText}>Cancel</Text>}
        </Pressable>
      </View>
    </View>
  );
}

function QualityChoice({
  selected,
  title,
  subtitle,
  onPress,
  disabled,
}: {
  selected: boolean;
  title: string;
  subtitle: string;
  onPress: () => void;
  disabled: boolean;
}) {
  return (
    <Pressable
      accessibilityRole="radio"
      accessibilityState={{ selected, disabled }}
      onPress={onPress}
      disabled={disabled}
      style={({ pressed }) => [styles.qualityChoice, selected && styles.qualityChoiceSelected, pressed && !disabled && styles.qualityPressed]}
    >
      <View style={styles.qualityChoiceHead}>
        <Text style={[styles.qualityChoiceTitle, selected && styles.qualityChoiceTitleSelected]}>{title}</Text>
        {selected ? <Ionicons name="checkmark-circle" size={16} color={palette.accent} /> : null}
      </View>
      <Text style={styles.qualityChoiceSubtitle}>{subtitle}</Text>
    </Pressable>
  );
}

function getStage(status: EnhancementStatus): string {
  if (status.stage) return status.stage;
  if (status.status === "queued") return "Queued with VanceAI — waiting for an upscaler";
  if (status.phase === "uploading") return "VanceAI is receiving the video";
  if (status.phase === "syncing") return "Preparing the source for AI processing";
  return "AI is restoring detail and upscaling";
}

export default function HomeScreen() {
  const [video, setVideo] = useState<ImagePickerAsset | null>(null);
  const [phase, setPhase] = useState<Phase>("empty");
  const [quality, setQuality] = useState<OutputQuality>("2k");
  const [jobId, setJobId] = useState<string | null>(null);
  const [jobToken, setJobToken] = useState<string | null>(null);
  const [resultUrl, setResultUrl] = useState<string | null>(null);
  const [resultInfo, setResultInfo] = useState<VideoOutput | null>(null);
  const [creditsEstimated, setCreditsEstimated] = useState<number | undefined>();
  const [compareSide, setCompareSide] = useState<CompareSide>("after");
  const [progress, setProgress] = useState(0);
  const [stage, setStage] = useState("Choose a clip to begin");
  const [providerPhase, setProviderPhase] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [saveProgress, setSaveProgress] = useState(0);
  const [isSaved, setIsSaved] = useState(false);
  const [saveNotice, setSaveNotice] = useState<string | null>(null);
  const [isCancelling, setIsCancelling] = useState(false);
  const pollTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const cancelTransferRef = useRef<CancelTransfer | null>(null);
  const cancelRequestedRef = useRef(false);

  const applyProviderStatus = useCallback((status: EnhancementStatus, currentJobId: string, currentJobToken: string): "active" | "terminal" => {
    setProviderPhase(status.phase ?? status.status);
    setProgress(Math.max(0, Math.min(100, status.progress)));
    setStage(getStage(status));
    if (status.result) setResultInfo(status.result);
    if (typeof status.creditsEstimated === "number") setCreditsEstimated(status.creditsEstimated);
    if (status.status === "succeeded" && status.resultAvailable) {
      setResultUrl(getEnhancementDownloadUrl(currentJobId, currentJobToken));
      setProgress(100);
      setCompareSide("after");
      setErrorMessage(null);
      setPhase("complete");
      return "terminal";
    }
    if (status.status === "failed" || status.status === "canceled") {
      setErrorMessage(status.message || (status.status === "canceled"
        ? "The VanceAI job was canceled. Any reserved credits were refunded."
        : "VanceAI could not finish this clip. Please try again."));
      setPhase("error");
      return "terminal";
    }
    return "active";
  }, []);

  useEffect(() => {
    if (phase !== "processing" || !jobId || !jobToken) return;
    let active = true;
    let transientFailures = 0;

    const poll = async () => {
      try {
        const status = await getEnhancementStatus(jobId, jobToken);
        if (!active) return;
        transientFailures = 0;
        if (applyProviderStatus(status, jobId, jobToken) === "terminal") return;
        pollTimer.current = setTimeout(() => void poll(), status.nextPollMs ?? 7_000);
      } catch (error) {
        if (!active) return;
        if (error instanceof EnhancementRequestError && !error.retryable) {
          setErrorMessage(error.message);
          setPhase("error");
          return;
        }
        transientFailures += 1;
        const waitMs = Math.min(60_000, 7_000 * 2 ** Math.min(transientFailures - 1, 3));
        setStage("Connection interrupted — reconnecting to VanceAI");
        pollTimer.current = setTimeout(() => void poll(), waitMs);
      }
    };

    void poll();
    return () => {
      active = false;
      if (pollTimer.current) clearTimeout(pollTimer.current);
    };
  }, [applyProviderStatus, jobId, jobToken, phase]);

  const pickVideo = async () => {
    if (phase === "uploading" || phase === "processing") return;
    setErrorMessage(null);
    setSaveNotice(null);
    try {
      const selection = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ["videos"],
        allowsEditing: false,
      });
      if (selection.canceled || !selection.assets[0]) return;
      const selected = selection.assets[0];
      setVideo(selected);
      setJobId(null);
      setJobToken(null);
      setResultUrl(null);
      setResultInfo(null);
      setCreditsEstimated(undefined);
      setProviderPhase(null);
      setIsSaved(false);
      setCompareSide("before");
      setProgress(0);
      setStage("Ready to upload securely to VanceAI");
      setPhase("ready");
    } catch {
      setErrorMessage("The video library could not be opened. Please try again.");
      setPhase(video ? "error" : "empty");
    }
  };

  const startEnhancement = async () => {
    if (!video || phase === "uploading" || phase === "processing") return;
    cancelRequestedRef.current = false;
    cancelTransferRef.current = null;
    setErrorMessage(null);
    setSaveNotice(null);
    setIsSaved(false);
    setJobId(null);
    setJobToken(null);
    setResultUrl(null);
    setResultInfo(null);
    setCreditsEstimated(undefined);
    setProviderPhase("uploading");
    setPhase("uploading");
    setProgress(0);
    setStage("Preparing a secure VanceAI upload");

    try {
      const upload = await createUploadSession(video);
      if (cancelRequestedRef.current) throw new Error("Video upload canceled.");
      setStage("Uploading source video directly to VanceAI");
      await uploadVideoDirect(
        video,
        upload,
        (percent) => {
          if (cancelRequestedRef.current) return;
          setProgress(percent);
          setStage(`Uploading source video · ${percent}%`);
        },
        (cancel) => { cancelTransferRef.current = cancel; },
      );
      cancelTransferRef.current = null;
      if (cancelRequestedRef.current) throw new Error("Video upload canceled.");
      setProgress(0);
      setProviderPhase("queued");
      setStage("Starting the VanceAI upscaler");
      const created = await createEnhancementJob(upload.uploadId, quality);
      setJobId(created.jobId);
      setJobToken(created.jobToken);
      setCreditsEstimated(created.creditsEstimated);
      setProviderPhase("queued");
      if (cancelRequestedRef.current) {
        const canceled = await cancelEnhancement(created.jobId, created.jobToken).catch(() => null);
        if (canceled?.status === "canceled") {
          setProviderPhase("canceled");
          setErrorMessage("VanceAI job canceled. Any reserved credits were refunded.");
          setPhase("error");
          return;
        }
        const latest = await getEnhancementStatus(created.jobId, created.jobToken).catch(() => null);
        if (latest && applyProviderStatus(latest, created.jobId, created.jobToken) === "terminal") return;
        cancelRequestedRef.current = false;
        setErrorMessage(null);
        setStage("Cancellation was not confirmed; VanceAI is still processing.");
        setPhase("processing");
        return;
      }
      setStage("Queued with VanceAI — waiting for an upscaler");
      setPhase("processing");
    } catch (error) {
      const message = error instanceof Error ? error.message : "The video could not be sent to VanceAI.";
      setErrorMessage(cancelRequestedRef.current
        ? "Video upload canceled before a provider job was submitted. No processing credits were reserved."
        : message);
      setPhase("error");
    } finally {
      cancelTransferRef.current = null;
      cancelRequestedRef.current = false;
    }
  };

  const cancelCurrent = async () => {
    if (isCancelling) return;
    cancelRequestedRef.current = true;
    setIsCancelling(true);
    try {
      if (cancelTransferRef.current) {
        await cancelTransferRef.current();
        cancelRequestedRef.current = false;
        setProviderPhase(null);
        setErrorMessage("Video upload canceled before a provider job was submitted. No processing credits were reserved.");
        setPhase("error");
        return;
      }
      if (jobId && jobToken && phase === "processing") {
        const canceled = await cancelEnhancement(jobId, jobToken);
        if (canceled.status === "canceled") {
          cancelRequestedRef.current = false;
          setProviderPhase("canceled");
          setErrorMessage("VanceAI job canceled. Any reserved credits were refunded.");
          setPhase("error");
          return;
        }
        const latest = await getEnhancementStatus(jobId, jobToken);
        if (applyProviderStatus(latest, jobId, jobToken) === "terminal") {
          cancelRequestedRef.current = false;
          return;
        }
        cancelRequestedRef.current = false;
        setErrorMessage(null);
        setStage("Cancellation was not confirmed; processing continues.");
        setPhase("processing");
        return;
      }
      cancelRequestedRef.current = false;
      setProviderPhase(null);
      setErrorMessage("Video upload canceled before a provider job was submitted. No processing credits were reserved.");
      setPhase("error");
    } catch (error) {
      if (jobId && jobToken) {
        const latest = await getEnhancementStatus(jobId, jobToken).catch(() => null);
        if (latest) {
          if (applyProviderStatus(latest, jobId, jobToken) === "active") {
            cancelRequestedRef.current = false;
            setErrorMessage(null);
            setStage("Could not confirm cancellation; checking job progress.");
            setPhase("processing");
          } else {
            cancelRequestedRef.current = false;
          }
          return;
        }
      }
      cancelRequestedRef.current = false;
      if (phase === "processing") {
        setErrorMessage(null);
        setStage("Could not confirm cancellation; reconnecting to the job.");
        setPhase("processing");
      } else {
        setErrorMessage(error instanceof Error ? error.message : "The enhancement could not be canceled.");
        setPhase("error");
      }
    } finally {
      cancelTransferRef.current = null;
      setIsCancelling(false);
    }
  };

  const saveResult = async () => {
    if (!resultUrl || !jobId || isSaving || isSaved) return;
    setIsSaving(true);
    setSaveProgress(0);
    setSaveNotice(null);
    try {
      if (Platform.OS === "web") {
        const link = document.createElement("a");
        link.href = resultUrl;
        link.download = `framefix-${quality}-upscaled.mp4`;
        link.rel = "noreferrer";
        document.body.appendChild(link);
        link.click();
        link.remove();
        setSaveNotice("Your enhanced MP4 download has started.");
        setIsSaved(true);
        return;
      }

      const permission = await MediaLibrary.requestPermissionsAsync(true, ["video"]);
      if (!permission.granted) throw new Error("Allow FrameFix to save videos to your gallery, then try again.");
      const cacheDirectory = FileSystem.cacheDirectory;
      if (!cacheDirectory) throw new Error("Temporary storage is unavailable on this device.");
      const destination = `${cacheDirectory}${cacheDirectory.endsWith("/") ? "" : "/"}framefix-${jobId}.mp4`;
      const downloadTask = FileSystem.createDownloadResumable(
        resultUrl,
        destination,
        { sessionType: FileSystem.FileSystemSessionType.BACKGROUND },
        (event) => {
          if (event.totalBytesExpectedToWrite > 0) {
            setSaveProgress(Math.min(100, Math.round((event.totalBytesWritten / event.totalBytesExpectedToWrite) * 100)));
          }
        },
      );
      const download = await downloadTask.downloadAsync();
      if (!download || download.status < 200 || download.status >= 300) {
        throw new Error("The enhanced video could not be downloaded. Check free storage and try again.");
      }
      await MediaLibrary.saveToLibraryAsync(download.uri);
      await FileSystem.deleteAsync(download.uri, { idempotent: true }).catch(() => undefined);
      setSaveNotice("Saved to your gallery. Your original clip is unchanged.");
      setIsSaved(true);
    } catch (error) {
      setSaveNotice(error instanceof Error ? error.message : "The video could not be saved. Please try again.");
    } finally {
      setIsSaving(false);
    }
  };

  const busy = phase === "uploading" || phase === "processing";
  const displayedVideoUri = phase === "complete" && compareSide === "after" ? resultUrl : video?.uri;
  const outputDimensions = resultInfo?.width && resultInfo?.height
    ? `${resultInfo.width} × ${resultInfo.height}`
    : quality === "4k" ? "Up to 3840 × 2160" : "2× AI upscale";
  const mainAction = phase === "complete" ? pickVideo : video ? startEnhancement : pickVideo;
  const mainActionLabel = phase === "uploading"
    ? "Uploading to VanceAI…"
    : phase === "processing"
      ? "AI upscale in progress…"
      : phase === "complete"
        ? "Enhance another clip"
        : video
          ? phase === "error" ? "Try VanceAI again" : `Upscale to ${quality === "4k" ? "4K" : "2K"}`
          : "Choose a video";

  return (
    <ScreenContainer containerClassName="bg-[#080C13]" safeAreaClassName="bg-[#080C13]" className="bg-[#080C13]">
      <StatusBar style="light" />
      <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">
        <View style={styles.page}>
          <View style={styles.brandRow}>
            <View style={styles.brandLockup}>
              <View style={styles.brandMark}>
                <View style={styles.brandFrame} />
                <View style={styles.brandSpark} />
              </View>
              <View>
                <Text style={styles.brandName}>FRAMEFIX</Text>
                <Text style={styles.brandTag}>VIDEO RESTORATION</Text>
              </View>
            </View>
            <View style={styles.headerBadge}>
              <Ionicons name="sparkles" size={13} color={palette.accent} />
              <Text style={styles.headerBadgeText}>VANCEAI UPSCALER</Text>
            </View>
          </View>

          <View style={styles.hero}>
            <Text style={styles.eyebrow}>FROM BLURRY TO BRILLIANT</Text>
            <Text style={styles.headline}>Make the moment{"\n"}<Text style={styles.headlineAccent}>clear again.</Text></Text>
            <Text style={styles.subtitle}>Reduce grain and blur, restore detail, and upscale your video with VanceAI.</Text>
          </View>

          <View style={styles.sectionHeading}>
            <Text style={styles.sectionTitle}>Your clip</Text>
            <Text style={styles.sectionHint}>{video ? "SOURCE VIDEO" : "START WITH A VIDEO"}</Text>
          </View>

          <View style={styles.videoCard}>
            {video && displayedVideoUri ? (
              <View>
                <VideoPreview key={displayedVideoUri} uri={displayedVideoUri} />
                <View style={styles.videoOverlayTop}>
                  <View style={styles.videoTag}>
                    <View style={[styles.statusDot, phase === "complete" && compareSide === "after" && styles.statusDotAccent]} />
                    <Text style={styles.videoTagText}>
                      {phase === "complete" ? compareSide === "after" ? `ENHANCED · ${quality.toUpperCase()}` : "ORIGINAL" : "ORIGINAL"}
                    </Text>
                  </View>
                  {video.duration ? <View style={styles.durationTag}><Text style={styles.durationText}>{formatDuration(video.duration)}</Text></View> : null}
                </View>
              </View>
            ) : (
              <Pressable
                onPress={() => void pickVideo()}
                accessibilityRole="button"
                accessibilityLabel="Choose a video from your device"
                style={({ pressed }) => [styles.emptyPreview, pressed && styles.pressed]}
              >
                <View style={styles.emptyGlow} />
                <View style={styles.emptyFrameTop} />
                <View style={styles.emptyIcon}><Ionicons name="film-outline" size={25} color={palette.accent} /></View>
                <Text style={styles.emptyTitle}>Bring in a clip</Text>
                <Text style={styles.emptyCopy}>Choose a blurry or grainy video to restore</Text>
                <View style={styles.browsePill}>
                  <Ionicons name="add" size={16} color={palette.accentInk} />
                  <Text style={styles.browsePillText}>Browse videos</Text>
                </View>
                <Text style={styles.supportText}>MP4 or MOV · large files supported</Text>
              </Pressable>
            )}

            {video ? (
              <View style={styles.videoInfo}>
                <View style={styles.fileNameRow}>
                  <View style={styles.fileIcon}><Ionicons name="videocam-outline" size={17} color={palette.blue} /></View>
                  <View style={styles.fileNameCopy}>
                    <Text numberOfLines={1} style={styles.fileName}>{video.fileName || video.file?.name || "Selected video"}</Text>
                    <Text style={styles.fileSize}>{formatSize(video.fileSize ?? video.file?.size)}</Text>
                  </View>
                  {!busy ? <Pressable onPress={() => void pickVideo()} style={styles.changeButton} accessibilityRole="button"><Text style={styles.changeButtonText}>Change</Text></Pressable> : null}
                </View>
                <View style={styles.detailDivider} />
                <View style={styles.detailsRow}>
                  <Detail icon="time-outline" label="Duration" value={formatDuration(video.duration)} />
                  <View style={styles.detailDividerVertical} />
                  <Detail icon="scan-outline" label="Resolution" value={video.width && video.height ? `${video.width} × ${video.height}` : "Provider reads on upload"} />
                  <View style={styles.detailDividerVertical} />
                  <Detail icon="document-outline" label="Format" value={video.mimeType?.split("/").pop()?.toUpperCase() || "VIDEO"} />
                </View>
              </View>
            ) : null}

            {phase === "complete" && resultUrl ? (
              <View style={styles.compareWrap}>
                <View style={styles.compareIntro}>
                  <View>
                    <Text style={styles.compareTitle}>Review the restore</Text>
                    <Text style={styles.compareSub}>Output: {outputDimensions}{resultInfo?.codec ? ` · ${resultInfo.codec.toUpperCase()}` : ""}</Text>
                  </View>
                  <View style={styles.readyPill}><Ionicons name="checkmark-circle" size={14} color={palette.accent} /><Text style={styles.readyPillText}>READY</Text></View>
                </View>
                <View style={styles.compareSwitch}>
                  <Pressable onPress={() => setCompareSide("before")} style={[styles.compareOption, compareSide === "before" && styles.compareOptionActive]}>
                    <Text style={[styles.compareOptionText, compareSide === "before" && styles.compareOptionTextActive]}>Before</Text>
                  </Pressable>
                  <Pressable onPress={() => setCompareSide("after")} style={[styles.compareOption, compareSide === "after" && styles.compareOptionActive]}>
                    <Text style={[styles.compareOptionText, compareSide === "after" && styles.compareOptionTextActive]}>After · {quality.toUpperCase()}</Text>
                  </Pressable>
                </View>
              </View>
            ) : null}
          </View>

          <View style={styles.sectionHeadingAfter}>
            <Text style={styles.sectionTitle}>Output quality</Text>
            <View style={styles.qualityBadge}><Ionicons name="sparkles" size={12} color={palette.accent} /><Text style={styles.qualityBadgeText}>VANCEAI</Text></View>
          </View>

          <View style={styles.qualityPicker} accessibilityRole="radiogroup" accessibilityLabel="Select upscale quality">
            <QualityChoice selected={quality === "2k"} title="2K · 2×" subtitle="Balanced upscale" onPress={() => setQuality("2k")} disabled={busy} />
            <QualityChoice selected={quality === "4k"} title="4K · 4×" subtitle="Up to 3840 × 2160" onPress={() => setQuality("4k")} disabled={busy} />
          </View>
          <Text style={styles.qualityNote}>VanceAI scales from your original; exact output dimensions depend on the source and are capped at 3840 × 2160.</Text>

          <View style={styles.restoreCard}>
            <EnhancementFeature icon="sparkles-outline" title="AI detail restoration" detail="Rebuild detail and reduce soft blur and grain" />
            <View style={styles.featureDivider} />
            <EnhancementFeature icon="scan-outline" title="Choose your upscale" detail="VanceAI's 2× or 4× video model" />
            <View style={styles.featureDivider} />
            <EnhancementFeature icon="expand-outline" title="Up to 4K UHD" detail="Provider output limit: 3840 × 2160" />
          </View>

          {busy ? (
            <ProgressCard
              progress={progress}
              stage={stage}
              providerPhase={providerPhase}
              creditsEstimated={creditsEstimated}
              onCancel={() => void cancelCurrent()}
              cancelling={isCancelling}
            />
          ) : null}

          {phase === "error" && errorMessage ? (
            <View style={styles.errorCard}><Ionicons name="alert-circle-outline" size={19} color={palette.red} /><Text style={styles.errorText}>{errorMessage}</Text></View>
          ) : null}

          <Pressable
            onPress={() => void mainAction()}
            disabled={busy || isSaving}
            accessibilityRole="button"
            style={({ pressed }) => [styles.primaryButton, (busy || isSaving) && styles.buttonDisabled, pressed && !busy && styles.buttonPressed]}
          >
            {busy ? <ActivityIndicator size="small" color={palette.accentInk} /> : phase === "complete" ? <Ionicons name="add" size={19} color={palette.accentInk} /> : <Ionicons name={video ? "sparkles" : "cloud-upload-outline"} size={18} color={palette.accentInk} />}
            <Text style={styles.primaryButtonText}>{mainActionLabel}</Text>
            {!busy && phase !== "complete" ? <Ionicons name="arrow-forward" size={17} color={palette.accentInk} /> : null}
          </Pressable>

          {phase === "complete" && resultUrl ? (
            <Pressable onPress={() => void saveResult()} disabled={isSaving || isSaved} accessibilityRole="button" style={({ pressed }) => [styles.saveButton, pressed && !isSaving && styles.saveButtonPressed]}>
              {isSaving ? <ActivityIndicator size="small" color={palette.accent} /> : <Ionicons name={isSaved ? "checkmark-circle-outline" : "download-outline"} size={19} color={palette.accent} />}
              <Text style={styles.saveButtonText}>
                {isSaved ? Platform.OS === "web" ? "Downloaded" : "Saved to Gallery" : isSaving ? Platform.OS === "web" ? "Preparing download…" : `Saving video · ${saveProgress}%` : Platform.OS === "web" ? "Download enhanced video" : "Save to Gallery"}
              </Text>
            </Pressable>
          ) : null}

          {saveNotice ? <Text style={styles.saveNotice}>{saveNotice}</Text> : null}

          <View style={styles.privacyLine}>
            <Ionicons name="lock-closed-outline" size={12} color={palette.subtle} />
            <Text style={styles.privacyText}>On your request, the video uploads directly to VanceAI, not through this app’s server. Credits are reserved when processing starts; failed or canceled jobs are refunded.</Text>
          </View>
          <Text style={styles.footerNote}>VanceAI API · 2×/4× upscale · maximum output 3840 × 2160</Text>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  scrollContent: { flexGrow: 1, paddingBottom: 24 },
  page: { width: "100%", maxWidth: 540, alignSelf: "center", paddingHorizontal: 20, paddingTop: 12, paddingBottom: 30 },
  brandRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 28 },
  brandLockup: { flexDirection: "row", alignItems: "center", gap: 11 },
  brandMark: { width: 42, height: 42, borderRadius: 14, backgroundColor: "#17241C", alignItems: "center", justifyContent: "center", borderWidth: 1, borderColor: "#31472C", overflow: "hidden" },
  brandFrame: { width: 22, height: 22, borderWidth: 2, borderColor: palette.accent, borderRadius: 6 },
  brandSpark: { position: "absolute", width: 7, height: 7, borderRadius: 4, backgroundColor: palette.accent, top: 10, right: 10, borderWidth: 1, borderColor: "#17241C" },
  brandName: { color: palette.text, fontSize: 13, fontWeight: "800", letterSpacing: 2.1 },
  brandTag: { color: palette.subtle, fontSize: 9, fontWeight: "700", letterSpacing: 1.55, marginTop: 3 },
  headerBadge: { flexDirection: "row", alignItems: "center", gap: 6, borderRadius: 30, borderWidth: 1, borderColor: "#283746", backgroundColor: "#101A20", paddingHorizontal: 11, paddingVertical: 8 },
  headerBadgeText: { color: "#D3E7B9", fontSize: 9, fontWeight: "800", letterSpacing: 1.1 },
  hero: { marginBottom: 26 },
  eyebrow: { color: palette.accent, fontSize: 10, fontWeight: "800", letterSpacing: 1.9, marginBottom: 10 },
  headline: { color: palette.text, fontSize: 34, lineHeight: 39, fontWeight: "800", letterSpacing: -1.35 },
  headlineAccent: { color: palette.accent },
  subtitle: { color: palette.muted, fontSize: 14, lineHeight: 21, marginTop: 10, maxWidth: 340 },
  sectionHeading: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 11 },
  sectionHeadingAfter: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginTop: 23, marginBottom: 11 },
  sectionTitle: { color: palette.text, fontSize: 16, fontWeight: "700", letterSpacing: -0.2 },
  sectionHint: { color: palette.subtle, fontSize: 9, fontWeight: "800", letterSpacing: 1.45 },
  videoCard: { borderRadius: 24, borderWidth: 1, borderColor: palette.border, backgroundColor: palette.panel, padding: 10, overflow: "hidden" },
  emptyPreview: { minHeight: 270, borderRadius: 19, backgroundColor: "#0B111A", borderWidth: 1, borderColor: "#273541", borderStyle: "dashed", alignItems: "center", justifyContent: "center", overflow: "hidden", padding: 22 },
  emptyGlow: { position: "absolute", width: 180, height: 180, borderRadius: 100, backgroundColor: "#172819", opacity: 0.38, top: -70, right: -50 },
  emptyFrameTop: { position: "absolute", width: 120, height: 120, borderRadius: 28, borderWidth: 1, borderColor: "#21332A", top: 22, left: 24, opacity: 0.65 },
  emptyIcon: { width: 54, height: 54, borderRadius: 18, alignItems: "center", justifyContent: "center", backgroundColor: "#18261B", borderWidth: 1, borderColor: "#31472C", marginBottom: 14 },
  emptyTitle: { color: palette.text, fontSize: 17, fontWeight: "700", letterSpacing: -0.2 },
  emptyCopy: { color: palette.muted, fontSize: 12, marginTop: 5, textAlign: "center" },
  browsePill: { flexDirection: "row", alignItems: "center", gap: 6, backgroundColor: palette.accent, paddingHorizontal: 15, paddingVertical: 10, borderRadius: 14, marginTop: 17 },
  browsePillText: { color: palette.accentInk, fontSize: 12, fontWeight: "800" },
  supportText: { color: palette.subtle, fontSize: 10, marginTop: 13 },
  pressed: { opacity: 0.82 },
  videoOverlayTop: { position: "absolute", top: 10, left: 10, right: 10, flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  videoTag: { flexDirection: "row", alignItems: "center", gap: 6, backgroundColor: "rgba(5, 9, 14, 0.82)", borderWidth: 1, borderColor: "rgba(255,255,255,0.12)", borderRadius: 20, paddingHorizontal: 10, paddingVertical: 7 },
  statusDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: "#A5B7FF" },
  statusDotAccent: { backgroundColor: palette.accent },
  videoTagText: { color: "#F4F6F8", fontSize: 9, fontWeight: "800", letterSpacing: 1 },
  durationTag: { backgroundColor: "rgba(5, 9, 14, 0.82)", borderRadius: 14, paddingHorizontal: 9, paddingVertical: 6 },
  durationText: { color: "#F4F6F8", fontSize: 10, fontWeight: "700" },
  videoInfo: { paddingHorizontal: 7, paddingTop: 13, paddingBottom: 3 },
  fileNameRow: { flexDirection: "row", alignItems: "center", gap: 10 },
  fileIcon: { width: 34, height: 34, alignItems: "center", justifyContent: "center", borderRadius: 11, backgroundColor: "#202A3A" },
  fileNameCopy: { flex: 1, minWidth: 0 },
  fileName: { color: palette.text, fontSize: 12, fontWeight: "700" },
  fileSize: { color: palette.subtle, fontSize: 10, marginTop: 3 },
  changeButton: { borderWidth: 1, borderColor: palette.border, borderRadius: 10, paddingHorizontal: 10, paddingVertical: 7 },
  changeButtonText: { color: palette.blue, fontSize: 10, fontWeight: "700" },
  detailDivider: { height: 1, backgroundColor: palette.border, marginTop: 13, marginBottom: 12 },
  detailsRow: { flexDirection: "row", alignItems: "stretch" },
  detailCell: { flex: 1, minWidth: 0, paddingHorizontal: 5 },
  detailTop: { flexDirection: "row", alignItems: "center", gap: 5 },
  detailLabel: { color: palette.subtle, fontSize: 9, fontWeight: "700" },
  detailValue: { color: palette.text, fontSize: 10, fontWeight: "700", marginTop: 6 },
  detailDividerVertical: { width: 1, backgroundColor: palette.border, marginHorizontal: 4 },
  compareWrap: { paddingHorizontal: 5, paddingTop: 16, paddingBottom: 4 },
  compareIntro: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 12 },
  compareTitle: { color: palette.text, fontSize: 14, fontWeight: "700" },
  compareSub: { color: palette.subtle, fontSize: 10, marginTop: 3 },
  readyPill: { flexDirection: "row", alignItems: "center", gap: 5, borderRadius: 14, backgroundColor: "#1B2A19", paddingHorizontal: 9, paddingVertical: 6 },
  readyPillText: { color: palette.accent, fontSize: 9, fontWeight: "800", letterSpacing: 1 },
  compareSwitch: { flexDirection: "row", padding: 4, backgroundColor: "#0B111A", borderWidth: 1, borderColor: palette.border, borderRadius: 13 },
  compareOption: { flex: 1, alignItems: "center", paddingVertical: 9, borderRadius: 9 },
  compareOptionActive: { backgroundColor: "#26322B" },
  compareOptionText: { color: palette.subtle, fontSize: 11, fontWeight: "700" },
  compareOptionTextActive: { color: palette.accent },
  qualityBadge: { flexDirection: "row", alignItems: "center", gap: 5, paddingHorizontal: 9, paddingVertical: 6, borderRadius: 16, borderWidth: 1, borderColor: "#32422D", backgroundColor: "#162019" },
  qualityBadgeText: { color: palette.accent, fontSize: 9, fontWeight: "800", letterSpacing: 1 },
  qualityPicker: { flexDirection: "row", gap: 10, marginBottom: 9 },
  qualityChoice: { flex: 1, borderRadius: 15, borderWidth: 1, borderColor: palette.border, backgroundColor: palette.panel, paddingHorizontal: 13, paddingVertical: 12 },
  qualityChoiceSelected: { borderColor: "#738E47", backgroundColor: "#17221B" },
  qualityPressed: { opacity: 0.82 },
  qualityChoiceHead: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  qualityChoiceTitle: { color: palette.muted, fontSize: 13, fontWeight: "800" },
  qualityChoiceTitleSelected: { color: palette.accent },
  qualityChoiceSubtitle: { color: palette.subtle, fontSize: 10, marginTop: 5 },
  qualityNote: { color: palette.subtle, fontSize: 10, lineHeight: 14, marginBottom: 14 },
  restoreCard: { borderRadius: 21, borderWidth: 1, borderColor: palette.border, backgroundColor: palette.panel, paddingHorizontal: 15, paddingVertical: 4 },
  featureRow: { flexDirection: "row", alignItems: "center", gap: 11, paddingVertical: 13 },
  featureIcon: { width: 32, height: 32, borderRadius: 11, backgroundColor: "#202A21", alignItems: "center", justifyContent: "center" },
  featureCopy: { flex: 1 },
  featureTitle: { color: palette.text, fontSize: 12, fontWeight: "700" },
  featureDetail: { color: palette.subtle, fontSize: 10, marginTop: 3 },
  featureDivider: { height: 1, backgroundColor: palette.border, marginLeft: 43 },
  progressCard: { borderRadius: 20, backgroundColor: "#111A24", borderWidth: 1, borderColor: "#34442C", padding: 15, marginTop: 16 },
  progressHeader: { flexDirection: "row", alignItems: "center", gap: 10 },
  progressOrb: { width: 36, height: 36, borderRadius: 13, backgroundColor: "#202B21", alignItems: "center", justifyContent: "center" },
  progressCopy: { flex: 1 },
  progressTitle: { color: palette.text, fontSize: 12, fontWeight: "700" },
  progressStage: { color: palette.muted, fontSize: 10, marginTop: 3 },
  progressNumber: { color: palette.accent, fontSize: 12, fontWeight: "800" },
  track: { height: 5, borderRadius: 4, backgroundColor: "#29323B", marginTop: 15, overflow: "hidden" },
  trackFill: { height: "100%", borderRadius: 4, backgroundColor: palette.accent },
  progressFooter: { flexDirection: "row", alignItems: "center", gap: 8, marginTop: 8 },
  progressFootnote: { flex: 1, color: palette.subtle, fontSize: 9, lineHeight: 13 },
  cancelButton: { minWidth: 50, alignItems: "center", justifyContent: "center", paddingVertical: 5 },
  cancelButtonText: { color: palette.muted, fontSize: 10, fontWeight: "700" },
  errorCard: { flexDirection: "row", alignItems: "flex-start", gap: 9, backgroundColor: "#271919", borderWidth: 1, borderColor: "#5C3432", borderRadius: 14, padding: 12, marginTop: 15 },
  errorText: { flex: 1, color: "#FFC3BD", fontSize: 11, lineHeight: 16 },
  primaryButton: { minHeight: 54, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 10, backgroundColor: palette.accent, borderRadius: 17, marginTop: 20, paddingHorizontal: 16 },
  primaryButtonText: { color: palette.accentInk, fontSize: 13, fontWeight: "800", letterSpacing: 0.1 },
  buttonDisabled: { opacity: 0.65 },
  buttonPressed: { transform: [{ scale: 0.99 }], opacity: 0.9 },
  saveButton: { minHeight: 51, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 9, backgroundColor: "#111A22", borderWidth: 1, borderColor: "#3D5334", borderRadius: 16, marginTop: 10 },
  saveButtonPressed: { opacity: 0.8 },
  saveButtonText: { color: palette.accent, fontSize: 13, fontWeight: "800" },
  saveNotice: { color: "#C7D4BC", textAlign: "center", fontSize: 11, lineHeight: 16, marginTop: 9 },
  privacyLine: { flexDirection: "row", alignItems: "flex-start", justifyContent: "center", gap: 6, marginTop: 17, paddingHorizontal: 4 },
  privacyText: { flex: 1, color: palette.subtle, fontSize: 9, lineHeight: 14, textAlign: "center" },
  footerNote: { color: "#4E5B6D", fontSize: 9, textAlign: "center", marginTop: 8 },
});
