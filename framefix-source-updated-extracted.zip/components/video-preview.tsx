import { useVideoPlayer, VideoView } from "expo-video";
import { StyleSheet, View } from "react-native";

export function VideoPreview({ uri }: { uri: string }) {
  const player = useVideoPlayer(uri, (videoPlayer) => {
    videoPlayer.loop = true;
    videoPlayer.muted = true;
  });

  return (
    <View style={styles.frame}>
      <VideoView
        player={player}
        style={styles.video}
        contentFit="contain"
        nativeControls
        playsInline
      />
    </View>
  );
}

const styles = StyleSheet.create({
  frame: {
    width: "100%",
    height: 226,
    overflow: "hidden",
    borderRadius: 20,
    backgroundColor: "#05080E",
  },
  video: { width: "100%", height: "100%" },
});
