/** @type {const} */
const themeColors = {
  primary: { light: '#C4FA62', dark: '#C4FA62' },
  background: { light: '#080C13', dark: '#080C13' },
  surface: { light: '#101722', dark: '#101722' },
  foreground: { light: '#F3F6F8', dark: '#F3F6F8' },
  muted: { light: '#9AA6B7', dark: '#9AA6B7' },
  border: { light: '#263243', dark: '#263243' },
  success: { light: '#C4FA62', dark: '#C4FA62' },
  warning: { light: '#F5C868', dark: '#F5C868' },
  error: { light: '#FF938B', dark: '#FF938B' },
};

module.exports = { themeColors };
